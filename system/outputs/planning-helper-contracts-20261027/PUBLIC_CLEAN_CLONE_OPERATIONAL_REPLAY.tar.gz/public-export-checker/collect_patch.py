"""Export edits by any method as a diff against the original public Broken snapshot."""
import argparse,hashlib,json,pathlib,re,subprocess
def collect(workspace,output):
 workspace=workspace.resolve(strict=True);record=json.loads((workspace/'workspace.json').read_text())
 source=pathlib.Path(record['source_root']).resolve(strict=True)
 if not source.is_relative_to(workspace):raise ValueError('source root escapes prepared workspace')
 base=record.get('baseline_commit','')
 if not record.get('git_initialized') or not re.fullmatch(r'[a-f0-9]{40,64}',base):raise ValueError('Prepare with --git and a recorded initial baseline commit')
 def git(*args,**kwargs):return subprocess.check_output(['git','-C',str(source),*args],**kwargs)
 git('cat-file','-e',base+'^{commit}')
 new=git('ls-files','--others','--exclude-standard','-z').split(b'\0')
 paths=[p.decode('utf-8') for p in new if p]
 for offset in range(0,len(paths),128):git('add','--intent-to-add','--',*paths[offset:offset+128])
 # Comparing to recorded initial commit also captures methods that commit edits.
 diff=git('diff','--no-ext-diff','--no-textconv','--binary',base,'--')
 output=output.resolve(strict=False);output.parent.mkdir(parents=True,exist_ok=True)
 with output.open('xb') as stream:stream.write(diff)
 return {'case_id':record['case_id'],'baseline_commit':base,'patch_sha256':hashlib.sha256(diff).hexdigest(),'patch_bytes':len(diff),'patch':str(output),'hidden_evaluator_loaded':False}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workspace',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
 try:print(json.dumps(collect(a.workspace,a.output)));return 0
 except (OSError,ValueError,subprocess.CalledProcessError) as e:print(json.dumps({'status':'PATCH_EXPORT_ERROR','detail':str(e)}));return 2
if __name__=='__main__':raise SystemExit(main())
