package main
import (
 "context"
 "encoding/json"
 "fmt"
 "io"
 "os"
 "path/filepath"
 "strings"
 kptfile "github.com/kptdev/kpt/api/kptfile/v1"
 "github.com/kptdev/kpt/pkg/fn"
 "github.com/kptdev/kpt/pkg/lib/kptops"
 "github.com/kptdev/kpt/pkg/lib/runneroptions"
 "github.com/kptdev/kpt/pkg/printer"
 "sigs.k8s.io/kustomize/kyaml/filesys"
 syaml "sigs.k8s.io/yaml"
)
type object = map[string]interface{}
type check struct { ID string `json:"id"`; Status string `json:"status"`; Observed interface{} `json:"observed"` }
type seen struct { Names []string `json:"ordinary_inputs"`; Config string `json:"function_config"` }
type runtime struct { Seen map[string]seen }
type runner struct { RT *runtime; Name string }
func metadata(o object) object { if m,ok:=o["metadata"].(map[string]interface{});ok{return m};return object{} }
func name(o object) string { s,_:=metadata(o)["name"].(string);return s }
func (rt *runtime) GetRunner(_ context.Context, f *kptfile.Function) (fn.FunctionRunner,error) {
 if f.Exec!="owner" && f.Exec!="later" && f.Exec!="control" {return nil,fmt.Errorf("unknown public probe function %q", f.Exec)}
 return &runner{rt,f.Exec},nil
}
func (r *runner) Run(in io.Reader,out io.Writer) error {
 b,err:=io.ReadAll(in);if err!=nil{return err}
 var list struct { APIVersion string `json:"apiVersion"`; Kind string `json:"kind"`; Items []object `json:"items"`; FunctionConfig object `json:"functionConfig,omitempty"` }
 if err=syaml.Unmarshal(b,&list);err!=nil{return err}
 observation:=seen{Names:[]string{},Config:name(list.FunctionConfig)}
 for _,item:=range list.Items {
  n:=name(item);observation.Names=append(observation.Names,n)
  if (r.Name=="owner" && n=="workload") || (r.Name=="later" && n=="settings") {
   d,ok:=item["data"].(map[string]interface{});if !ok{d=object{};item["data"]=d};d[r.Name]="observed"
  }
 }
 r.RT.Seen[r.Name]=observation
 return json.NewEncoder(out).Encode(list)
}
func contains(v []string,s string) bool {for _,x:=range v{if x==s{return true}};return false}
func get(o object,key string) interface{} { d,_:=o["data"].(map[string]interface{});return d[key] }
func main(){
 results:=[]check{}
 add:=func(id string,ok bool,observed interface{}){status:="FAIL";if ok{status="PASS"};results=append(results,check{id,status,observed})}
 for _,kind:=range []string{"mutator","validator","control","mutator_selector","mutator_exclusion"}{
  dir,err:=os.MkdirTemp("","ce-public-configpath-");if err!=nil{panic(err)}
  pipeline:="  mutators:\n    - exec: owner\n      configPath: settings.yaml\n    - exec: later\n"
  if kind=="validator"{pipeline="  mutators:\n    - exec: later\n  validators:\n    - exec: owner\n      configPath: settings.yaml\n"}
  if kind=="control"{pipeline="  mutators:\n    - exec: control\n"}
  if kind=="mutator_selector" {pipeline=`  mutators:
    - exec: owner
      configPath: settings.yaml
      selectors:
        - kind: ConfigMap
    - exec: later
`}
  if kind=="mutator_exclusion" {pipeline=`  mutators:
    - exec: owner
      configPath: settings.yaml
      exclude:
        - name: settings
    - exec: later
`}
  files:=map[string]string{"Kptfile":"apiVersion: kpt.dev/v1\nkind: Kptfile\nmetadata:\n  name: demo\npipeline:\n"+pipeline,
   "settings.yaml":"apiVersion: v1\nkind: ConfigMap\nmetadata:\n  name: settings\ndata:\n  initial: config\n",
   "workload.yaml":"apiVersion: v1\nkind: ConfigMap\nmetadata:\n  name: workload\ndata:\n  initial: workload\n"}
  for path,text:=range files{if err=os.WriteFile(filepath.Join(dir,path),[]byte(text),0600);err!=nil{panic(err)}}
  rt:=&runtime{Seen:map[string]seen{}}
  renderer:=kptops.Renderer{PkgPath:dir,FileSystem:filesys.MakeFsOnDisk(),Runtime:rt,RunnerOptions:runneroptions.RunnerOptions{AllowExec:true}}
  _,runErr:=renderer.Execute(printer.WithContext(context.Background(),printer.New(io.Discard,io.Discard)))
  rendered:=map[string]object{}
  for _,path:=range []string{"settings.yaml","workload.yaml"}{
   b,e:=os.ReadFile(filepath.Join(dir,path));if e==nil{var o object;if syaml.Unmarshal(b,&o)==nil{rendered[name(o)]=o}}
  }
  identities:=map[string]bool{}; resourceCount:=0; identityAnnotationCount:=0; inventoryError:=""
  _=filepath.Walk(dir,func(path string, info os.FileInfo, walkErr error) error {
   if walkErr!=nil {inventoryError=walkErr.Error();return nil}; if info.IsDir() || (!strings.HasSuffix(path,".yaml") && !strings.HasSuffix(path,".yml") && filepath.Base(path)!="Kptfile") {return nil}
   b,e:=os.ReadFile(path);if e!=nil{inventoryError=e.Error();return nil}
   for _,doc:=range strings.Split(string(b),"\n---") {
    if strings.TrimSpace(doc)=="" {continue};var o object
    if e=syaml.Unmarshal([]byte(doc),&o);e!=nil {inventoryError=e.Error();continue}
    if o["kind"]==nil {inventoryError="missing resource kind";continue}
    id:=fmt.Sprint(o["apiVersion"],"/",o["kind"],"/",metadata(o)["namespace"],"/",name(o));resourceCount++;identities[id]=true
    annotations,_:=metadata(o)["annotations"].(map[string]interface{}); if _,found:=annotations["internal.config.kubernetes.io/kpt-resource-id"];found {identityAnnotationCount++}
   };return nil
  })
  inventory:=object{"resource_count":resourceCount,"identities":identities,"error":inventoryError,"identity_annotation_count":identityAnnotationCount}
  state:=object{"functions":rt.Seen,"render_error":fmt.Sprint(runErr),"rendered":rendered,"inventory":inventory}
  add(kind+".resource_inventory",runErr==nil && inventoryError=="" && resourceCount==3 && len(identities)==3,state)
  clean:=inventoryError=="" && identityAnnotationCount==0; for _, obj:=range rendered { a,_:=metadata(obj)["annotations"].(map[string]interface{}); if _,found:=a["internal.config.kubernetes.io/kpt-resource-id"];found {clean=false} }
  add(kind+".identity_annotations_cleaned",runErr==nil && clean,state)
  if kind=="control"{
   add("control.ordinary_inputs",runErr==nil && contains(rt.Seen["control"].Names,"settings") && contains(rt.Seen["control"].Names,"workload"),state)
   add("control.final_resources",runErr==nil && get(rendered["settings"],"initial")=="config" && get(rendered["workload"],"initial")=="workload",state)
  }else{
   owner:=rt.Seen["owner"]
   add(kind+".owner_binding",runErr==nil && owner.Config=="settings",state)
   add(kind+".owner_excludes_config",runErr==nil && !contains(owner.Names,"settings") && contains(owner.Names,"workload"),state)
   if strings.HasPrefix(kind,"mutator"){add(kind+".later_sees_config",runErr==nil && contains(rt.Seen["later"].Names,"settings"),state)}
   final:=runErr==nil && get(rendered["settings"],"later")=="observed" && get(rendered["settings"],"initial")=="config" && get(rendered["workload"],"initial")=="workload"
   if strings.HasPrefix(kind,"mutator"){final=final && get(rendered["workload"],"owner")=="observed"}
   add(kind+".config_retained",runErr==nil && get(rendered["settings"],"initial")=="config",state)
   add(kind+".workload_retained",runErr==nil && get(rendered["workload"],"initial")=="workload",state)
   add(kind+".config_transformed",runErr==nil && get(rendered["settings"],"later")=="observed",state)
   if strings.HasPrefix(kind,"mutator"){add(kind+".workload_transformed",runErr==nil && get(rendered["workload"],"owner")=="observed",state)}
   _ = final
  }
  os.RemoveAll(dir)
 }
 payload:=object{"probe_id":"kpt-configpath-v4","checks":results,"scope":"Public requirement-derived Renderer API exercise with local function stand-ins; no container functions, private fixtures or independent oracle"}
 b,_:=json.Marshal(payload);fmt.Println(strings.TrimSpace(string(b)))
}
