from __future__ import annotations

import re
import math
import hashlib
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from contractedge.retrieval.edges import build_direct_reference_edges


class TokenCounterUnavailable(ValueError):
    pass


@dataclass(frozen=True)
class CandidateSet:
    candidates: tuple[Mapping[str, Any], ...]
    selected_ids: tuple[str, ...]
    dropped_ids: tuple[str, ...]
    ranking_features: Mapping[str, Mapping[str, int]]
    edges: tuple[Mapping[str, Any], ...]
    context_tokens: int
    max_context_tokens: int
    top_n: int
    extension_used: bool = False
    drop_reasons: Mapping[str, str] | None = None
    supplemental_evidence: tuple[Mapping[str, Any], ...] = ()
    context_audit: tuple[Mapping[str, Any], ...] = ()
    required_endpoint_ids: tuple[str, ...] = ()

    @property
    def selected_count(self) -> int:
        return len(self.selected_ids)


def _terms(value: str) -> set[str]:
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", value).replace('_', ' ')
    stop = {'the', 'and', 'for', 'that', 'this', 'with', 'from', 'when', 'then', 'must', 'should',
            'would', 'could', 'have', 'has', 'had', 'are', 'was', 'were', 'been', 'being', 'into',
            'without', 'also', 'instead', 'than', 'through', 'after', 'before', 'even', 'though',
            'while', 'its', 'their', 'these', 'those', 'not', 'both', 'only', 'supplied', 'provided', 'is', 'be'}
    terms = {token.casefold() for token in re.findall(r"[A-Za-z0-9_]+", spaced)
             if len(token) > 1 and token.casefold() not in stop}
    # Share adopt/adopts, group/groups etc. without losing the original token.
    return terms | {t[:-1] for t in terms if len(t) > 4 and t.endswith('s') and not t.endswith('ss')}


def literal_identifiers(requirement: str) -> set[str]:
    quoted = re.findall(r'`([^`\n]+)`', requirement)
    camel = [t for t in re.findall(r'[A-Za-z_$][A-Za-z0-9_$]*', requirement)
             if re.search(r'[a-z][A-Z]', t) or '_' in t]
    return {s.casefold() for s in [*quoted, *camel] if s.strip()}


def _identity(candidate: Mapping[str, Any]) -> tuple[str, str, str]:
    locator = candidate.get("locator", {})
    text = str(candidate.get('text', ''))
    declaration = candidate.get('declaration_locator')
    if isinstance(locator, Mapping) and isinstance(declaration, Mapping):
        a, b = locator.get('start_line'), locator.get('end_line')
        start, end = declaration.get('start_line'), declaration.get('end_line')
        if (all(type(v) is int for v in (a, b, start, end)) and a <= start <= end <= b
                and hashlib.sha256(text.encode()).hexdigest() == candidate.get('content_digest')):
            body = ''.join(text.splitlines(keepends=True)[start-a:end-a+1])
            if hashlib.sha256(body.encode()).hexdigest() == candidate.get('declaration_content_digest'):
                locator, text = declaration, body
    # Producers may omit the default first column; byte content and line
    # identity must still agree. Non-default columns remain distinct.
    if isinstance(locator, Mapping):
        locator = {k:v for k,v in locator.items() if not (k == 'column_start' and v == 1)}
    return (str(candidate.get("snapshot_id", "")), str(candidate.get("path", "")),
            repr((sorted(locator.items()) if isinstance(locator, Mapping) else locator,
                  hashlib.sha256(text.encode()).hexdigest())) )


def requires_gap_delivery(unit: Mapping[str, Any]) -> bool:
    """Keep real/legacy required roles; nonmatching lexical context is optional.

    An exact anchor or explicit requirement always wins when identities merge.
    """
    roles = unit.get("gap_role_keys", [])
    return bool(unit.get("required_for_gap_delivery") or (roles and (
        unit.get("optional_gap_context") is not True or any(role.endswith(":anchor") for role in roles))))


def merge_gap_context_optional(*units: Mapping[str, Any]) -> bool:
    """A merged role is optional only if every role contribution is optional."""
    contributors = [unit for unit in units if unit.get("gap_role_keys")]
    return bool(contributors) and all(not requires_gap_delivery(unit) for unit in contributors)


def _rank(candidates: Sequence[Mapping[str, Any]], requirement: str, observable: str | None):
    requirement_terms = _terms(requirement)
    observable_terms = _terms(observable or "")
    identifiers = literal_identifiers(requirement)
    unique: dict[tuple[str, str, str], Mapping[str, Any]] = {}
    for candidate in candidates:
        identity = _identity(candidate)
        if identity not in unique:
            unique[identity] = candidate
        else:
            previous = unique[identity]
            # Retain a complete excerpt and its real locator/ID. Adjacent API
            # comments add source contracts, not a second declaration slot.
            winner = max((candidate, previous), key=lambda u:(
                not u.get('truncated', False), len(str(u.get('text', '')))))
            unique[identity] = {**previous, **candidate, **winner,
                'anchor_priority': max(previous.get('anchor_priority', 0), candidate.get('anchor_priority', 0)),
                'gap_role_keys': sorted(set(previous.get('gap_role_keys',[]))|set(candidate.get('gap_role_keys',[]))),
                'evidence_gap_refs': sorted(set(previous.get('evidence_gap_refs', [])) | set(candidate.get('evidence_gap_refs', []))),
                'references': sorted(set(previous.get('references', [])) | set(candidate.get('references', []))),
                'declared_symbols': sorted(set(previous.get('declared_symbols', [])) | set(candidate.get('declared_symbols', []))),
                'superseded_unit_ids': sorted((set(previous.get('superseded_unit_ids', []))
                    | set(candidate.get('superseded_unit_ids', [])) | {previous['id'], candidate['id']}) - {winner['id']})}
            if 'optional_gap_context' in previous or 'optional_gap_context' in candidate:
                unique[identity]['optional_gap_context'] = merge_gap_context_optional(previous, candidate)
            if previous.get('required_for_gap_delivery') or candidate.get('required_for_gap_delivery'):
                unique[identity]={**unique[identity],'required_for_gap_delivery':True}
            if previous.get('precondition_review_required') or candidate.get('precondition_review_required'):
                unique[identity]={**unique[identity],'precondition_review_required':True}
            if previous.get('same_receiver_callee_support') or candidate.get('same_receiver_callee_support'):
                unique[identity]={**unique[identity],'same_receiver_callee_support':True}
    from contractedge.retrieval.frontier import production_frontier
    sibling_ids = {r['source_evidence_id'].removeprefix('SRC-')
                   for r in production_frontier(list(unique.values()), requirement)}
    features: dict[str, dict[str, int]] = {}
    for candidate in unique.values():
        text = str(candidate.get("text", ""))
        content_terms = _terms(text)
        path_terms = _terms(str(candidate.get("path", "")))
        exact = len(requirement_terms & (content_terms | path_terms))
        observed = len(observable_terms & content_terms) if observable else 0
        requirement_hits = len(requirement_terms & content_terms)
        features[str(candidate["id"])] = {"lexical_sibling_candidate": int(candidate["id"] in sibling_ids),
                                           "exact_identifier_hits": exact,
                                           "resource_kind_hits": int(str(candidate.get("resource_kind","")).casefold() in requirement_terms or str(candidate.get("resource_kind","")).casefold()+"s" in requirement_terms) if candidate.get("resource_kind") else 0,
                                           "literal_identifier_hits": sum(t in text.casefold() for t in identifiers),
                                           "mechanism_symbol_hits": len(requirement_terms & _terms(' '.join(
                                               [*map(str, candidate.get('declared_symbols', [])), *map(str, candidate.get('references', []))]))),
                                           "anchor_priority": int(candidate.get('anchor_priority', 0)),
                                           "observable_term_hits": observed,
                                           "requirement_term_hits": requirement_hits,
                                           "hop_distance": int(candidate.get("hop_distance", 0))}
    ordered = sorted(unique.values(), key=lambda item: (
        -features[str(item['id'])]['anchor_priority'],
        -features[str(item["id"])]["exact_identifier_hits"],
        -features[str(item["id"])]["observable_term_hits"],
        -features[str(item["id"])]["requirement_term_hits"],
        features[str(item["id"])]["hop_distance"], str(item.get("path", "")),
        int(item.get("locator", {}).get("start_line", 0)) if isinstance(item.get("locator"), Mapping) else 0,
    ))
    return ordered, features


def _overlap(a, b):
    if (a.get('path'), a.get('origin_kind'), a.get('snapshot_id')) != (b.get('path'), b.get('origin_kind'), b.get('snapshot_id')):
        return 0.0
    x, y = a.get('locator', {}), b.get('locator', {})
    a0, a1, b0, b1 = x.get('start_line'), x.get('end_line'), y.get('start_line'), y.get('end_line')
    if not all(type(v) is int for v in (a0, a1, b0, b1)):
        return 0.0
    return max(0, min(a1, b1) - max(a0, b0) + 1) / max(1, min(a1 - a0 + 1, b1 - b0 + 1))


def _select(ordered, features, edges, *, top_n: int, max_context_tokens: int,
            token_counter: Callable[[str], int], extension_used: bool) -> CandidateSet:
    if token_counter is None:
        raise TokenCounterUnavailable("an explicit model tokenizer/token counter is required")
    selected: list[str] = []
    dropped: list[str] = []
    reasons: dict[str, str] = {}
    total = 0
    selected_payload: list[Mapping[str, Any]] = []
    remaining = list(ordered)
    required_roles=set()
    while remaining:
        def marginal(item):
            f = features[str(item['id'])]
            same_path = sum((p.get('path'), p.get('origin_kind')) == (item.get('path'), item.get('origin_kind'))
                            for p in selected_payload)
            overlap = max((_overlap(item, p) for p in selected_payload), default=0)
            relevance = (1 + f['exact_identifier_hits'] + f['observable_term_hits']
                         + 12 * f.get('literal_identifier_hits', 0) + 2 * f.get('mechanism_symbol_hits', 0))
            scope_cost = 1 + math.log2(1 + max(0, int(item.get('scope_path_rank', 0)))) / 2
            covered_gaps = {g for p in selected_payload for g in p.get('evidence_gap_refs', [])}
            new_gaps = set(item.get('evidence_gap_refs', [])) - covered_gaps
            # A restored, query-related declaration answers a body-coverage
            # gap more directly than its import/header fallback. Soft preference
            # only; documents, configuration and necessary text remain eligible.
            restored = (bool(item.get('expanded_from_unit_id')) and not item.get('truncated')
                        and f.get('mechanism_symbol_hits', 0) > 0)
            score = ((1 + 8 * f['anchor_priority']) * relevance * (4 if f.get('resource_kind_hits') else 1) * (1 - .9 * overlap)
                     * (1 + 4 * len(new_gaps)) * (2 if restored else 1)
                     * (2 if f.get("lexical_sibling_candidate") else 1)
                     / ((1 + same_path) * scope_cost))
            return score
        # Stable initial ordering resolves equal marginal scores. No category is
        # excluded and no file quota forces irrelevant evidence into the request.
        uncovered=[u for u in remaining if set(u.get('gap_role_keys',[]))-required_roles]
        primary=[u for u in uncovered if u.get('required_for_gap_delivery')
                 or any(role.endswith(':anchor') for role in u.get('gap_role_keys',[]))]
        reserved=sum(bool(p.get('gap_role_keys')) for p in selected_payload)
        # Explicit delivery requirements are hard constraints within the same
        # Top-N/token bounds. The six-slot preference limits optional roles;
        # it must not silently demote already required lifecycle evidence.
        mandatory=[u for u in remaining if u.get('required_for_gap_delivery')
                   or any(role.endswith(':anchor') for role in u.get('gap_role_keys',[]))]
        # After required endpoints, prefer the at-most-two bodies reached by
        # explicit same-receiver calls over unconnected lexical matches. They
        # still consume ordinary Top-N/token space and may be dropped for cost.
        dependencies=[u for u in remaining
                      if u.get('same_receiver_callee_support')]
        pool=mandatory or ((primary or uncovered) if uncovered and reserved<min(6,top_n)
                           else dependencies or remaining)
        candidate = max(pool, key=marginal)
        remaining.remove(candidate)
        cid = str(candidate["id"])
        if len(selected) >= top_n:
            dropped.append(cid)
            reasons[cid] = "TOP_N_LIMIT"
            continue
        cost = int(token_counter(str(candidate.get("text", ""))))
        if cost < 0:
            raise ValueError("token counter cannot return a negative count")
        if total + cost > max_context_tokens:
            dropped.append(cid)
            reasons[cid] = "CONTEXT_BUDGET"
            continue
        selected.append(cid)
        features[cid] = {**features[cid], 'selection_step': len(selected),
                         'new_gap_ids': sorted(set(candidate.get('evidence_gap_refs', [])) -
                            {g for p in selected_payload for g in p.get('evidence_gap_refs', [])}),
                         'max_overlap_percent': int(100 * max((_overlap(candidate, p) for p in selected_payload), default=0))}
        selected_payload.append(candidate)
        required_roles.update(candidate.get('gap_role_keys',[]))
        total += cost
    selected_set = set(selected)
    aliases = {alias:u['id'] for u in selected_payload for alias in u.get('superseded_unit_ids', [])}
    remapped = [{**edge, 'source':aliases.get(edge.get('source'),edge.get('source')),
                'target':aliases.get(edge.get('target'),edge.get('target'))} for edge in edges]
    valid_edges = tuple(edge for edge in remapped
                        if edge.get("source") in selected_set and edge.get("target") in selected_set
                        and edge.get('source') != edge.get('target')
                        and edge.get("edge_kind") in {"SYNTACTIC", "INFERRED"})
    return CandidateSet(tuple(selected_payload), tuple(selected), tuple(dropped), features, valid_edges,
                        total, max_context_tokens, top_n, extension_used, reasons)



def trim_context_bundle(candidate_set: CandidateSet, *, request_tokens: int, limit: int) -> CandidateSet:
    """Remove the lowest-priority connected evidence bundle, recording lost edges.

    Reference edges are retrieval hints, not proven causal relations. Isolated
    evidence is a one-element bundle; immutable input and source IDs stay intact.
    """
    from dataclasses import replace
    selected = list(candidate_set.candidates)
    neighbors = {str(c['id']): set() for c in selected}
    for edge in candidate_set.edges:
        a, b = str(edge['source']), str(edge['target'])
        if a in neighbors and b in neighbors:
            neighbors[a].add(b); neighbors[b].add(a)
    groups = []
    unseen = set(neighbors)
    while unseen:
        pending = [min(unseen)]; group = set()
        while pending:
            key = pending.pop()
            if key not in group:
                group.add(key); pending.extend(neighbors[key] - group)
        unseen -= group; groups.append(group)
    if not groups:
        return candidate_set
    positions = {str(c['id']): i for i, c in enumerate(selected)}
    protected={str(c['id']) for c in selected if requires_gap_delivery(c)} | set(candidate_set.required_endpoint_ids)
    unprotected=[g for g in groups if not g&protected]
    removed = max(unprotected or groups, key=lambda g: (min(positions[k] for k in g), sorted(g)))
    if (removed & protected or len(removed)==len(selected)) and len(selected)>1:
        # A lexical component is not an indivisible semantic proof. Even when
        # there are several components, remove optional scaffolding before
        # sacrificing a required source endpoint in any of them.
        removable=[c for c in selected if str(c['id']) not in protected]
        ordinary=[c for c in removable if not candidate_set.ranking_features.get(str(c['id']),{}).get('lexical_sibling_candidate')]
        if ordinary or removable:
            item=max(ordinary or removable,key=lambda c:(bool(c.get('truncated')),len(c.get('text','')),positions[str(c['id'])]))
            removed={str(item['id'])}
    kept = tuple(c for c in selected if str(c['id']) not in removed)
    edges = tuple(e for e in candidate_set.edges if str(e['source']) not in removed and str(e['target']) not in removed)
    return replace(candidate_set, candidates=kept, selected_ids=tuple(str(c['id']) for c in kept),
        dropped_ids=tuple(dict.fromkeys([*candidate_set.dropped_ids, *sorted(removed)])), edges=edges,
        drop_reasons={**(candidate_set.drop_reasons or {}), **{k: 'FULL_REQUEST_CONTEXT_BUNDLE' for k in removed}},
        context_audit=candidate_set.context_audit + ({'request_tokens_before': request_tokens, 'limit': limit,
            'removed_ids': sorted(removed), 'removed_reference_edges': len(candidate_set.edges) - len(edges),
            'interpretation': 'Bounded reference bundle removed; no causal correctness claim'},))


def build_candidate_set(requirement: str, observable: str | None, units: Sequence[Mapping[str, Any]],
                        edges: Sequence[Mapping[str, Any]], *, top_n: int,
                        max_context_tokens: int, token_counter: Callable[[str], int] | None) -> CandidateSet:
    if top_n <= 0 or max_context_tokens <= 0:
        raise ValueError("top_n and max_context_tokens must be positive")
    ordered, features = _rank(units, requirement, observable)
    return _select(ordered, features, edges, top_n=top_n, max_context_tokens=max_context_tokens,
                   token_counter=token_counter, extension_used=False)


def extend_once(candidate_set: CandidateSet, evidence_gaps: Sequence[Mapping[str, Any]],
                extension_candidates: Sequence[Mapping[str, Any]], *, max_context_tokens: int,
                token_counter: Callable[[str], int] | None) -> CandidateSet:
    if candidate_set.extension_used:
        raise ValueError("candidate set permits only one evidence-gap extension")
    locatable = [gap for gap in evidence_gaps
                 if any((gap.get("locator_hint") or {}).get(key) for key in ("search_term", "path", "symbol"))]
    if not locatable:
        raise ValueError("an evidence-gap extension requires a locatable gap")
    combined = [{**dict(u),'required_for_gap_delivery':True}
                if u['id'] in candidate_set.required_endpoint_ids else u
                for u in candidate_set.candidates] + list(extension_candidates)
    search_terms = []
    for gap in locatable:
        hint = gap.get("locator_hint") or {}
        search_terms.extend(str(hint.get(key, "")) for key in ("search_term", "path", "symbol"))
    # A located gap takes priority over initial anchors. Otherwise Top-N=1
    # could keep the original seed forever and never inspect its direct callee.
    combined = [{**dict(item), 'anchor_priority': 3}
                if any(term and term.casefold() in (str(item.get('path', '')) + '\n' +
                           str(item.get('text', ''))).casefold() for term in search_terms)
                else item for item in combined]
    gap_ids = {str(gap.get('id', '')) for gap in locatable}
    combined = [{**dict(item), 'anchor_priority': 4}
                if item.get('scope_extension') in {'EVIDENCE_GAP_SEED_UNIT', 'EVIDENCE_GAP_DIRECT_NEIGHBOR', 'EVIDENCE_GAP_EXACT_PATH', 'EVIDENCE_GAP_DIRECTORY_PATH'}
                and gap_ids.intersection(item.get('evidence_gap_refs', [])) else item
                for item in combined]
    ordered, features = _rank(combined, " ".join(search_terms), None)
    combined_edges = build_direct_reference_edges(combined)
    result=_select(ordered, features, combined_edges, top_n=candidate_set.top_n,
                   max_context_tokens=max_context_tokens, token_counter=token_counter, extension_used=True)
    from dataclasses import replace
    # _rank canonicalizes identical locations; require the actual canonical ID
    # whose exact excerpt will enter the rebuilt diagnosis, not a discarded alias.
    required=tuple(dict.fromkeys(str(u['id']) for u in ordered
        if u.get('required_for_gap_delivery') or any(role.endswith(':anchor') for role in u.get('gap_role_keys',[]))))
    return replace(result,required_endpoint_ids=required)
