"""Conservative requirement normalization."""
