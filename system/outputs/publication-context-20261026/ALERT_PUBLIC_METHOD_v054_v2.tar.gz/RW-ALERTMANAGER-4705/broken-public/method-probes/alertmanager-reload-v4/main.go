package main
import (
 "bytes"
 "encoding/json"
 "fmt"
 "io"
 "net"
 "net/http"
 "os"
 "os/exec"
 "path/filepath"
 "sync"
 "time"
)
type check struct { ID string `json:"id"`; Status string `json:"status"`; Observed interface{} `json:"observed"` }
func fatal(v interface{}) { fmt.Fprintln(os.Stderr,"PROBE_ERROR:",v);os.Exit(2) }

func decodePublicGroups(reader io.Reader)(bool,bool,int,error){
 const limit=8*1024*1024
 b,e:=io.ReadAll(io.LimitReader(reader,limit+1));if e!=nil{return false,false,len(b),e}
 if len(b)>limit{
 decoder:=json.NewDecoder(bytes.NewReader(b));token,tokenErr:=decoder.Token()
 groups,duplicates:=0,0;identities:=map[string]bool{}
 if tokenErr==nil&&token==json.Delim('['){for decoder.More(){
  var group struct{Labels map[string]string `json:"labels"`;Receiver struct{Name string `json:"name"`} `json:"receiver"`}
  if decoder.Decode(&group)!=nil{break}
  if group.Receiver.Name!="null"||group.Labels["alertname"]==""{break};groups++
  key,_:=json.Marshal([]interface{}{group.Labels,group.Receiver.Name})
  if identities[string(key)]{duplicates++};identities[string(key)]=true
 }}
 if duplicates>0{emitPrefixFailure(groups,duplicates,len(identities),len(b))}
 return false,false,len(b),fmt.Errorf("groups response exceeds %d bytes; incomplete observation",limit)
}
 var list []struct{Labels map[string]string `json:"labels"`;Receiver struct{Name string `json:"name"`} `json:"receiver"`;Alerts []struct{Labels map[string]string `json:"labels"`} `json:"alerts"`}
 if e=json.Unmarshal(b,&list);e!=nil{return false,false,len(b),fmt.Errorf("groups JSON bytes=%d: %v",len(b),e)}
 found:=map[string]bool{};keys:=map[string]bool{};unique:=len(list)<=2048
 for _,g:=range list{
  encoded,_:=json.Marshal([]interface{}{g.Labels,g.Receiver.Name});key:=string(encoded)
  if keys[key]||g.Receiver.Name!="null"{unique=false};keys[key]=true
  for _,a:=range g.Alerts{if a.Labels["instance"]=="local"{found[a.Labels["alertname"]]=true}}
 }
 visible:=true;for i:=0;i<2048;i++{if !found[fmt.Sprintf("ContractEdgePublicReload-%03d",i)]{visible=false}}
 return visible,unique,len(b),nil
}


var prefixFailureOnce sync.Once
func emitPrefixFailure(groups,duplicates,unique,observedBytes int){
 prefixFailureOnce.Do(func(){
  observation:=map[string]interface{}{
   "counterexample_kind":"DUPLICATE_GROUP_IDENTITIES_IN_BOUNDED_PREFIX",
   "response_complete":false,"byte_limit":8*1024*1024,"observed_bytes":observedBytes,
   "complete_prefix_groups":groups,"duplicate_identities":duplicates,"unique_identities":unique,
   "scope":"Complete group objects in the bounded public response prefix; no visibility or absence claim"}
  json.NewEncoder(os.Stdout).Encode(map[string]interface{}{
   "probe_id":"alertmanager-reload-v4","partial_observation":true,
   "checks":[]check{{"groups.unique_for_declared_route","FAIL",observation}}})
  os.Exit(0)
 })
}

func main(){
 dir,e:=os.MkdirTemp("","ce-am-public-");if e!=nil{fatal(e)};defer os.RemoveAll(dir)
 binary:=filepath.Join(dir,"alertmanager")
 build:=exec.Command("go","build","-p=1","-trimpath","-o",binary,"./cmd/alertmanager");build.Stdout=os.Stderr;build.Stderr=os.Stderr
 if e=build.Run();e!=nil{fatal(e)}
 config:=filepath.Join(dir,"alertmanager.yml")
 write:=func(i int){text:=fmt.Sprintf("global:\n  resolve_timeout: %dm\nroute:\n  receiver: null\n  group_by: [alertname]\n  group_wait: 10m\n  group_interval: 10m\n  repeat_interval: 1h\nreceivers:\n- name: null\n",5+i%2)
 // Quote null because receiver names are strings in public configuration.
 text=string(bytes.ReplaceAll([]byte(text),[]byte(": null"),[]byte(": 'null'")))
 if e=os.WriteFile(config,[]byte(text),0600);e!=nil{fatal(e)}}
 write(0)
 listener,e:=net.Listen("tcp","127.0.0.1:0");if e!=nil{fatal(e)};addr:=listener.Addr().String();listener.Close()
 process:=exec.Command(binary,"--config.file="+config,"--storage.path="+filepath.Join(dir,"data"),"--web.listen-address="+addr,"--cluster.listen-address=","--log.level=error")
 log,e:=os.Create(filepath.Join(dir,"server.log"));if e!=nil{fatal(e)};process.Stdout=log;process.Stderr=log
 if e=process.Start();e!=nil{fatal(e)}
 defer func(){process.Process.Kill();process.Wait();log.Close()}()
 client:=&http.Client{Timeout:2*time.Second};base:="http://"+addr
 request:=func(method,path string,data []byte)([]byte,int,error){q,e:=http.NewRequest(method,base+path,bytes.NewReader(data));if e!=nil{return nil,0,e};q.Header.Set("Content-Type","application/json");r,e:=client.Do(q);if e!=nil{return nil,0,e};defer r.Body.Close();b,e:=io.ReadAll(io.LimitReader(r.Body,1024*1024));return b,r.StatusCode,e}
 ready:=false
 for end:=time.Now().Add(20*time.Second);time.Now().Before(end);{_,code,err:=request("GET","/-/ready",nil);if err==nil&&code==200{ready=true;break};time.Sleep(50*time.Millisecond)}
 if !ready{b,_:=os.ReadFile(filepath.Join(dir,"server.log"));fatal("server readiness: "+string(b))}
 alert:=[]map[string]interface{}{};const expectedGroups=2048;for i:=0;i<expectedGroups;i++{alert=append(alert,map[string]interface{}{"labels":map[string]string{"alertname":fmt.Sprintf("ContractEdgePublicReload-%03d",i),"instance":"local"},"annotations":map[string]string{},"startsAt":time.Now().Add(-time.Minute).UTC().Format(time.RFC3339Nano),"endsAt":time.Now().Add(10*time.Minute).UTC().Format(time.RFC3339Nano)})}
 data,_:=json.Marshal(alert);_,code,e:=request("POST","/api/v2/alerts",data);if e!=nil||code/100!=2{fatal(fmt.Sprint("post alert: ",code,e))}
 groups:=func()(bool,bool,error){
 q,e:=http.NewRequest("GET",base+"/api/v2/alerts/groups",nil);if e!=nil{return false,false,e}
 r,e:=client.Do(q);if e!=nil{return false,false,e};defer r.Body.Close()
 if r.StatusCode!=200{return false,false,fmt.Errorf("groups HTTP %d",r.StatusCode)}
 visible,unique,_,e:=decodePublicGroups(r.Body);return visible,unique,e
 }
 baseline:=false
 for end:=time.Now().Add(10*time.Second);time.Now().Before(end);{ok,_,e:=groups();if e!=nil{fatal(e)};if ok{baseline=true;break};time.Sleep(10*time.Millisecond)}
 if !baseline{fatal("public alert never formed a visible group")}
 var mu sync.Mutex;samples,missing,nonUnique:=0,0,0;returnSamples,returnMissing:=0,0;var sampleError error
 stop:=make(chan struct{});var workers sync.WaitGroup;workers.Add(4)
 for worker:=0;worker<4;worker++{go func(){defer workers.Done();ticker:=time.NewTicker(2*time.Millisecond);defer ticker.Stop();for{select{case <-stop:return;case <-ticker.C:ok,unique,e:=groups();mu.Lock();samples++;if e!=nil{sampleError=e};if e==nil&&!ok{missing++};if e==nil&&!unique{nonUnique++};mu.Unlock()}}}()}
 reloads:=0
 for i:=0;i<20;i++{time.Sleep(100*time.Millisecond);write(i+1);_,code,e:=request("POST","/-/reload",nil);if e!=nil||code/100!=2{close(stop);workers.Wait();fatal(fmt.Sprint("valid reload failed: ",code,e))};reloads++;ok,unique,err:=groups();if err!=nil{close(stop);workers.Wait();fatal(fmt.Sprint("reload-return observation: ",err))};returnSamples++;if !ok{returnMissing++};mu.Lock();if !unique{nonUnique++};mu.Unlock();time.Sleep(400*time.Millisecond)}
 close(stop);workers.Wait()
 if sampleError!=nil||samples<100{b,_:=os.ReadFile(filepath.Join(dir,"server.log"));if len(b)>65536{b=b[len(b)-65536:]};fatal(fmt.Sprint("sampling incomplete: ",samples,sampleError,"; production log: ",string(b)))}
 final,finalUnique,e:=groups();if e!=nil{fatal(e)}
 status:=func(v bool)string{if v{return "PASS"};return "FAIL"}
 observation:=map[string]interface{}{"baseline_visible":baseline,"injected_groups":expectedGroups,"successful_reloads":reloads,"samples":samples,"missing_samples":missing,"sampling_interval_ms":2,"sampling_workers":4,"after_visible":final,"non_unique_samples":nonUnique,"after_unique":finalUnique,"at_return_samples":returnSamples,"at_return_missing":returnMissing,"scope":"Local complete production process and HTTP API, twenty valid reloads with2048 groups and immediate reload-return samples; sampled continuity is not a proof of unsampled instants or distributed convergence"}
 checks:=[]check{{"groups.visible_during_reload",status(missing==0),observation},{"groups.visible_after_reload",status(final),observation},{"groups.unique_for_declared_route",status(nonUnique==0&&finalUnique),observation},{"groups.visible_at_reload_return",status(returnSamples==20&&returnMissing==0),observation}}
 json.NewEncoder(os.Stdout).Encode(map[string]interface{}{"probe_id":"alertmanager-reload-v4","checks":checks})
}
